import React, { useEffect, useState, useRef } from 'react';
import {
  Container, Box, Tabs, Tab, Paper, TextField, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  createTheme, ThemeProvider, Modal, Typography, Grid, useMediaQuery
} from '@mui/material';
import { collection, getDocs, setDoc, doc } from 'firebase/firestore';
import { db } from './firebase';
import SignaturePad from 'react-signature-canvas';
import logo from './logo.png';  // Replace with the actual path to your logo
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    background: {
      default: '#f5f5f5',
      paper: '#ffffff',
    },
    text: {
      primary: '#000000',
      secondary: '#5f6368',
    },
  },
  typography: {
    fontFamily: 'Poppins, sans-serif',
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '20px',
          textTransform: 'none',
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          marginBottom: '16px',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          padding: '20px',
          borderRadius: '10px',
        },
      },
    },
  },
});

const TabPanel = ({ children, value, index }) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

const TableComponent = ({ collectionName, rowLabels, columnLabels, specialRow, defaultRows }) => {
  const [rows, setRows] = useState(defaultRows || []);
  const [openSignatureModal, setOpenSignatureModal] = useState(false);
  const [currentRow, setCurrentRow] = useState(null);
  const [currentColumn, setCurrentColumn] = useState(null);
  const sigPadRef = useRef(null);
  const [openLevel, setOpenLevel] = useState("8.2");
  const [closeLevel, setCloseLevel] = useState("7.8");

  useEffect(() => {
    const fetchData = async () => {
      const querySnapshot = await getDocs(collection(db, collectionName));
      const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      if (!defaultRows) setRows(data);
    };
    fetchData();
  }, [collectionName, defaultRows]);

  const handleChange = (e, rowIndex, columnKey) => {
    const newRows = [...rows];
    if (!newRows[rowIndex]) {
      newRows[rowIndex] = {};
    }
    newRows[rowIndex][columnKey] = e.target.value;
    setRows(newRows);
  };

  const handleSave = async () => {
    for (const row of rows) {
      const rowDoc = doc(db, collectionName, row.id || rowLabels[rows.indexOf(row)]);
      await setDoc(rowDoc, row);
    }
    alert('Data saved successfully!');
  };

  const handleOpenSignatureModal = (rowIndex, columnKey) => {
    setCurrentRow(rowIndex);
    setCurrentColumn(columnKey);
    setOpenSignatureModal(true);
  };

  const handleSign = async () => {
    const signatureDataUrl = sigPadRef.current.getTrimmedCanvas().toDataURL('image/png');
    const newRows = [...rows];
    if (!newRows[currentRow]) {
      newRows[currentRow] = {};
    }
    newRows[currentRow][currentColumn] = signatureDataUrl;
    setRows(newRows);

    const rowDoc = doc(db, collectionName, newRows[currentRow].id || rowLabels[currentRow]);
    await setDoc(rowDoc, newRows[currentRow]);

    setOpenSignatureModal(false);
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Product Name</TableCell>
              {columnLabels.map((col, index) => (
                <TableCell key={index}>{col}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {specialRow && (
              <TableRow>
                <TableCell>{specialRow.label}</TableCell>
                <TableCell colSpan={4} style={{ textAlign: 'center' }}>
                  Open Level <TextField value={openLevel} onChange={(e) => setOpenLevel(e.target.value)} sx={{ width: '50px' }} InputProps={{ sx: { padding: 0 } }} /> & Close Level <TextField value={closeLevel} onChange={(e) => setCloseLevel(e.target.value)} sx={{ width: '50px' }} InputProps={{ sx: { padding: 0 } }} />
                </TableCell>
                <TableCell colSpan={2} onClick={() => handleOpenSignatureModal(0, 'Signature')} style={{ cursor: 'pointer', border: '1px solid #000', minHeight: '50px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {rows[0]?.['Signature'] ? <img src={rows[0]['Signature']} alt="Signature" style={{ width: '100px', height: '50px' }} /> : 'Click to Sign'}
                </TableCell>
              </TableRow>
            )}
            {rowLabels.map((rowLabel, rowIndex) => (
              <TableRow key={rowIndex}>
                <TableCell>{rowLabel}</TableCell>
                {columnLabels.map((col, colIndex) => (
                  <TableCell key={colIndex}>
                    {col === 'Signature' ? (
                      <div
                        onClick={() => handleOpenSignatureModal(rowIndex, col)}
                        style={{ cursor: 'pointer', border: '1px solid #000', minHeight: '50px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                      >
                        {rows[rowIndex]?.[col] ? (
                          <img src={rows[rowIndex][col]} alt="Signature" style={{ width: '100px', height: '50px' }} />
                        ) : (
                          'Click to Sign'
                        )}
                      </div>
                    ) : (
                      <TextField
                        value={rows[rowIndex]?.[col] || ''}
                        onChange={(e) => handleChange(e, rowIndex, col)}
                        InputProps={{ sx: { padding: 0 } }}
                      />
                    )}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" color="primary" onClick={handleSave} sx={{ mt: 2 }}>
        Save
      </Button>
      <Modal
        open={openSignatureModal}
        onClose={() => setOpenSignatureModal(false)}
        aria-labelledby="signature-modal-title"
        aria-describedby="signature-modal-description"
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '90%',
            maxWidth: 600,
            bgcolor: 'background.paper',
            border: '2px solid #000',
            boxShadow: 24,
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Typography id="signature-modal-title" variant="h6" component="h2" gutterBottom>
            Signature
          </Typography>
          <Box sx={{ width: '100%', height: 200, border: '1px solid #000' }}>
            <SignaturePad ref={sigPadRef} canvasProps={{ style: { width: '100%', height: '100%' } }} />
          </Box>
          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end', width: '100%' }}>
            <Button variant="contained" color="primary" onClick={handleSign}>
              Sign
            </Button>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

const Userform = () => {
  const [tabIndex, setTabIndex] = useState(0);
  const [reportDate, setReportDate] = useState(new Date());
  const [revisionDate, setRevisionDate] = useState(new Date());
  const [technicianName, setTechnicianName] = useState('');
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handleTabChange = (event, newIndex) => {
    setTabIndex(newIndex);
  };

  const handleAdditionalTableChange = (e, index) => {
    const newTableData = [...additionalTableData];
    newTableData[index].value = e.target.value;
    setAdditionalTableData(newTableData);
  };

  const handleSaveAdditionalTable = async () => {
    const additionalDataDoc = doc(db, 'additionalTable', 'additionalTableData');
    await setDoc(additionalDataDoc, { data: additionalTableData });
    alert('Additional data saved successfully!');
  };

  const condenserWaterLabels = ['Blowdown Set-point', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const condenserWaterColumns = ['Conductivity', 'Conductivity', 'Free Chlorine', 'Action', 'Name', 'Signature'];

  const chilledWaterLabels = [new Date().toLocaleDateString()];
  const chilledWaterColumns = ['Conductivity', 'Action', 'Name', 'Signature'];
  const chilledWaterDefaultRow = {
    Day: new Date().toLocaleDateString(),
    Conductivity: '',
    Action: '',
    Signature: ''
  };

  const condenserChemicalsLabels = [
    'PM3601 (25Kg)', 'Biocide AQ', 'PF CC6202 (20Kg)', 'PDV Salt (25Kg)', 'Sodium Hypochlorite (25 kg)',
    'BD 250C (25Kg)', 'PF CL4015 (CHW)', 'BD 350 (30Kg)', 'Dip slide (pcs)'
  ];
  const condenserChemicalsColumns = ['Opening Stock (Kg)', 'Closing Stock (Kg)', 'Consumption (Kg)', 'Consumption (Liters)', 'Name', 'Signature'];
  const condenserChemicalsDefaultRows = condenserChemicalsLabels.map(label => ({
    'Product Name': label,
    'Opening Stock (Kg)': '',
    'Closing Stock (Kg)': '',
    'Consumption (Kg)': '',
    'Consumption (Liters)': '',
    'Name': '',
    'Signature': ''
  }));

  const coolingTowerChemicalsLabels = [
    'Hydrochloric Acid (25Kg)', 'Sodium Hypochlorite (25Kg)', 'Phosphoric Acid (35Kg)',
    'Expired CHW Chemicals', 'Expired CT Chemicals'
  ];
  const coolingTowerChemicalsColumns = ['Available empty Jerry Cans in plants (06-11-2022)', 'Name', 'Signature'];
  const coolingTowerChemicalsDefaultRows = coolingTowerChemicalsLabels.map(label => ({
    'Product Name': label,
    'Available empty Jerry Cans in plants (06-11-2022)': '',
    'Name': '',
    'Signature': ''
  }));

  const [additionalTableData, setAdditionalTableData] = useState([
    { label: 'Condenser water dip slide test result as of: 30th October 2022', value: '10²', color: 'blue' },
    { label: 'Chilled water dip slide test result as of: 02nd November 2022', value: '10²', color: 'blue' },
    { label: 'Condenser system Make-up (m³ / USG)', value: '5243', color: 'red' },
    { label: 'Condenser system Blowdown (m³ / USG)', value: '950', color: 'red' },
    { label: 'Chilled water system Make-up (m³ / USG)', value: '0.62', color: 'red' },
    { label: 'C.O.C based on conductivity (Condenser/Make-up)', value: '8.0', color: 'blue' },
    { label: 'C.O.C based on (CT make-up/CT blowdown)', value: '5.5', color: 'blue' },
    { label: 'MIOX Running Hours (Hr.)', value: '344.0 hrs.', color: 'black' },
  ]);

  return (
    <ThemeProvider theme={theme}>
      <Container component={Paper} sx={{ p: 3, mt: 3 }}>
        <Box sx={{ textAlign: 'center', mb: 5 }}>
          <img src={logo} alt="Logo" style={{ width: isMobile ? '60%' : '200px', marginBottom: '10px' }} />
          <Typography variant={isMobile ? 'h6' : 'h5'} component="h1">
            Water Treatment Weekly Report
          </Typography>
          <Typography variant={isMobile ? 'h6' : 'h6'} component="h2">
            6th November 2022 to 12th November 2022
          </Typography>
        </Box>
        <Box sx={{ mb: 5 }}>
          <Grid container spacing={2} alignItems="stretch">
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ border: '1px solid #000', padding: '10px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Typography variant="h6" component="div">Operations Department</Typography>
                <Typography variant="body1" component="div">TOM-OPS-FM-2009</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ border: '1px solid #000', padding: '10px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Typography variant="h6" component="div">Revision 03 Dated</Typography>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    value={reportDate}
                    onChange={(newValue) => setReportDate(newValue)}
                    renderInput={(params) => <TextField {...params} sx={{ mt: 1 }} />}
                  />
                </LocalizationProvider>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ border: '1px solid #000', padding: '10px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Typography variant="h6" component="div">Replaces Revision 02 of</Typography>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    value={revisionDate}
                    onChange={(newValue) => setRevisionDate(newValue)}
                    renderInput={(params) => <TextField {...params} sx={{ mt: 1 }} />}
                  />
                </LocalizationProvider>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ border: '1px solid #000', padding: '10px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Typography variant="h6" component="div">Technician:</Typography>
                <TextField
                  type="text"
                  fullWidth
                  value={technicianName}
                  onChange={(e) => setTechnicianName(e.target.value)}
                  sx={{ mt: 1 }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabIndex} onChange={handleTabChange} centered>
            <Tab label="Condenser Water" />
            <Tab label="Chilled Water" />
            <Tab label="Condenser Chemicals" />
            <Tab label="Cooling Tower Chemicals" />
          </Tabs>
        </Box>
        <TabPanel value={tabIndex} index={0}>
          <TableComponent
            collectionName="condenserWater"
            rowLabels={condenserWaterLabels}
            columnLabels={condenserWaterColumns}
            specialRow={{ label: 'Blowdown Set-point' }}
          />
        </TabPanel>
        <TabPanel value={tabIndex} index={1}>
          <TableComponent
            collectionName="chilledWater"
            rowLabels={chilledWaterLabels}
            columnLabels={chilledWaterColumns}
            defaultRows={[chilledWaterDefaultRow]}
          />
        </TabPanel>
        <TabPanel value={tabIndex} index={2}>
          <TableComponent
            collectionName="condenserChemicals"
            rowLabels={condenserChemicalsLabels}
            columnLabels={condenserChemicalsColumns}
            defaultRows={condenserChemicalsDefaultRows}
          />
        </TabPanel>
        <TabPanel value={tabIndex} index={3}>
          <TableComponent
            collectionName="coolingTowerChemicals"
            rowLabels={coolingTowerChemicalsLabels}
            columnLabels={coolingTowerChemicalsColumns}
            defaultRows={coolingTowerChemicalsDefaultRows}
          />
        </TabPanel>
        <Box sx={{ mt: 5 }}>
          <TableContainer component={Paper}>
            <Table>
              <TableBody>
                {additionalTableData.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell sx={{ color: item.color }}>{item.label}</TableCell>
                    <TableCell>
                      {index < 2 ? (
                        <>
                          <Typography component="span" style={{ color: item.color, marginRight: '4px' }}>10</Typography>
                          <TextField
                            value={item.value.replace('10', '')}
                            onChange={(e) => handleAdditionalTableChange(e, index)}
                            sx={{ color: item.color, width: '30px', marginTop: -3, padding: 0 }}
                            InputProps={{ sx: { padding: 0 } }}
                            variant="standard"
                          />
                        </>
                      ) : (
                        <TextField
                          value={item.value}
                          onChange={(e) => handleAdditionalTableChange(e, index)}
                          InputProps={{ sx: { padding: 0 } }}
                        />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Button variant="contained" color="primary" onClick={handleSaveAdditionalTable} sx={{ mt: 2 }}>
            Save Additional Data
          </Button>
        </Box>
      </Container>
    </ThemeProvider>
  );
};

export default Userform;
